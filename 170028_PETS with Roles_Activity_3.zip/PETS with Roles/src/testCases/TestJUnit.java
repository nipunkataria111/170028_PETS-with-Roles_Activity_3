package testCases;

import static org.junit.Assert.assertNotSame;

import java.util.ArrayList;

import org.junit.Test;

import actions.ListItem;
import actions.TaskSpecific;
import actions.TaskSpecific.ECProducedItem;
import actions.TaskSpecific.ECUsedItem;
import actions.TaskSpecific.RolesItem;
import javafx.collections.ObservableList;

public class TestJUnit {

String eiu = "";
String ciu = "";
String diu = "";
ObservableList <RolesItem> roleList;
ObservableList<ECUsedItem> usedar;
ObservableList<ECProducedItem> proar;


 @Test
 public void LifecycleTab(){
	 String str2 = new String ("Lifecycle1");
	 String str1 = new String ("This is Lifecycle1");
String min = ListItem.theItemName;
assertNotSame(min, str2);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str1);
   }
 
 @Test
 public void TaskTab(){
	 String str2 = new String ("Lifecycle1");
	 String str19 = new String ("Task1");
	 String str20 = new String ("This is Task1");
	
roleList  = TaskSpecific.theRolesDetailList.getItems();
ArrayList<RolesItem> foo = new ArrayList<RolesItem>(roleList);
foo.forEach((n) -> eiu += n+",");

usedar = TaskSpecific.theUsedDetailList.getItems();
ArrayList<ECUsedItem> foo1 = new ArrayList<ECUsedItem>(usedar);
foo1.forEach((n1) -> ciu += n1+",");

proar = TaskSpecific.theProducedDetailList.getItems();
ArrayList<ECProducedItem> foo2 = new ArrayList<ECProducedItem>(proar);
foo2.forEach((n2) -> diu += n2+",");

assertNotSame(eiu, str2);
assertNotSame(ciu, str2);
assertNotSame(diu, str2);

String min = ListItem.theItemName;
assertNotSame(min, str19);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str20);
   }
 
 @Test
 public void StepTab(){
	 String str3 = new String ("Step1");
	 String str4 = new String ("This is Step1");
String min = ListItem.theItemName;
assertNotSame(min, str3);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str4);
   }
 
 @Test
 public void ConditionTab(){
	 String str5 = new String ("Condition1");
	 String str6 = new String ("This is Condition1");
String min = ListItem.theItemName;
assertNotSame(min, str5);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str6);
   }
 
 @Test
 public void RoleTab(){
	 String str7 = new String ("Role1");
	 String str8 = new String ("This is Role1");
String min = ListItem.theItemName;
assertNotSame(min, str7);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str8);
   }

 @Test
 public void EffortCategoriesTab(){
	 String str9 = new String ("Effort Category 1");
	 String str10 = new String ("This is Effort Category 1");
String min = ListItem.theItemName;
assertNotSame(min, str9);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str10);
   }
 
 @Test
 public void ArtifactsTab(){
	 String str11 = new String ("Artifact1");
	 String str12 = new String ("This is Artifact1");
String min = ListItem.theItemName;
assertNotSame(min, str11);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str12);
   }
 
 @Test
 public void PlanTab(){
	 String str13 = new String ("Plan1");
	 String str14 = new String ("This is Plan1");
String min = ListItem.theItemName;
assertNotSame(min, str13);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str14);
   }
 
 @Test
 public void InterruptionTab(){
	 String str15 = new String ("Interruption1");
	 String str16 = new String ("This is Interruption1");
String min = ListItem.theItemName;
assertNotSame(min, str15);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str16);
   }

 @Test
 public void DefectsTab(){
	 String str17 = new String ("Defect1");
	 String str18 = new String ("This is Defect1");
String min = ListItem.theItemName;
assertNotSame(min, str17);

String min2 = ListItem.theItemDescription;
assertNotSame(min2, str18);
   }

}

